COPY YOUR REAL GRAPH FILES INTO THIS DIRECTORY:

- graph_nodes_unified.jsonl
- edges_unified.jsonl

The frontend renders these files directly. It does not create synthetic graph entities.
