# Rare Disease Atlas frontend

## Install and run

```bash
npm install
npm run dev
```

Then open the localhost URL Vite prints.

## Required real data

Put these two existing files into `public/data/`:

- `graph_nodes_unified.jsonl`
- `edges_unified.jsonl`

From your current Hacknation repo, from the frontend directory:

```bash
cp ../data/graph_nodes_unified.jsonl public/data/
cp ../data/edges_unified.jsonl public/data/
```

The UI uses the real unified graph only. It has no fake fallback graph.

## Included

- vis-network browser graph
- smooth physics and draggable nodes
- directed arrows and relationship labels
- global search
- progressive reveal / double-click expansion
- node inspector
- edge evidence inspector
- source/provenance fields
- PubMed source links
- research landscape
- patient action journey
- responsive dark UI
